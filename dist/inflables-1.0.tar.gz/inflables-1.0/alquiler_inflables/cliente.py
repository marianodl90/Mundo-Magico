
class Cliente:
    def __init__(self, nombre:str, apellido:str, telefono:int):
        self.nombre = nombre
        self.apellido = apellido
        self.telefono = telefono
        
        
        
        
    def __str__(self):
         print (f"Reserva realizada")
         return f"El nombre del cliente es {self.nombre} {self.apellido}, y su telefono es {self.telefono}"

    def agregar_reserva(self, plaza:str, fecha, seña:int):
        self.reservas = []
        self.reservas.append({"plaza": plaza, "fecha": fecha, "seña": seña})

    
    def mostrar_reserva(self):
        for elemento in self.reservas:
            print("Se reservo", elemento["plaza"], "para el dia", elemento["fecha"],"y pago una seña de",elemento["seña"])
    

