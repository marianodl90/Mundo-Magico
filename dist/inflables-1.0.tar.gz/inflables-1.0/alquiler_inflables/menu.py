from cliente import Cliente


cliente_uno = Cliente("Mariano", "De Luis", 2604416169)
print(cliente_uno)
cliente_uno.agregar_reserva("Inflable", 26/5/2025, 20000)
cliente_uno.mostrar_reserva()

