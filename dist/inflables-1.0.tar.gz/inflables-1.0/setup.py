from setuptools import setup

setup(
    name="inflables",
    version="1.0",
    description="Paquete para gestionar alquiler de inflables",
    author="Mariano de Luis",
    author_email= "marianodeluis1990@gmail.com",
    packages= ["alquiler_inflables"] 
   
)
